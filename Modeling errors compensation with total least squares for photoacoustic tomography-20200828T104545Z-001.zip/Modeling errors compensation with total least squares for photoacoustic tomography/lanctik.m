function [xlam, lamopt, k, eta, lamv] = lanctik( A, b, estype, lambdarange, ...
						itmax, reorth, rst, debug)
%LBDTIK	Tikhonov regularization by Lanczos bidiagonalization
%
%   x=lbdtik(A,b) computes the Tikhonov regularized solution of the linear
%   system Ax=b, i.e.
%      min ||Ax-b||^2 + lambda^2 * ||x||^2
%   choosing the parameter lambda by minimizing an estimate of the error.
%
%   Optional input parameters: x=lbdtik(A,b,nu,lambdarange,itmax,reorth)
%      nu: index of the estimate (default 3)
%      lambdarange: interval for lambda (def. [1e-12,1e2])
%      itmax: maximum number of iterations for Lanczos process (def. 50)
%      reorth: flag to deactivate reorthogonalization (def. 1)
%   An empty parameter sets to default value.
%
%   Optional output parameters: [x,lamest,k,eta,lam]=lbdtik(...)
%      lamest: value of lambda which minimizes the error estimate
%      k: iterations performed by the Lanczos process
%      eta: values of the error estimate which have been computed
%      lam: corresponding lambda values

%   For debug: x=lbdtik(A,b,nu,lambdarange,itmax,reorth,[],debug)
%      if debug is not zero displays intermediate results for "debug"
%      seconds, if debug=inf it pauses until a key is pressed.

%   See:
%   L. Reichel, G. Rodriguez, S. Seatzu.
%   Error estimates for large-scale ill-posed problems.
%   Submitted.

%   Lothar Reichel, Kent State University, U.S.A.
%      Email: reichel@math.kent.edu
%   Giuseppe Rodriguez, University of Cagliari, Italy
%      Email: rodriguez@unica.it
%
%  Last revised August 5, 2008

if (nargin < 2)
	error( 'Too few parameters')
end

[m,n] = size(A);

if (nargin < 3) || isempty(estype),  estype = 3;  end
if (nargin < 4) || isempty(lambdarange),  lambdarange = [1e-12;1e2];  end
if (nargin < 5) || isempty(itmax),  itmax = 50;  end
if (nargin < 6) || isempty(reorth),  reorth = 1;  end
if (nargin < 7) || isempty(rst) || (rst == 0),  rst = itmax;  end
if (nargin < 8) || isempty(debug),  debug = 0;  end

nlambda = 10;		% number of lambda values for initial grid
tol = 1e-2;		% tolerance for upper and lower bounds of eta
lammax = 64;		% max number of lambda values
tau = 1e-2;		% default accuracy for lambda

% lambda grid
lambdarange = sort(lambdarange(:));
llamfirst = log10(lambdarange(1));
llamlast = log10(lambdarange(2));
lstep = (llamlast-llamfirst)/(nlambda-1);
llam = llamfirst + lstep*[0:nlambda-1]';	% log-equispaced sampling

% upper and lower bounds, eta and lambda values
n_r = zeros(nlambda,2);		% bounds for ||r||
n_Atr = zeros(nlambda,2);	% bounds for ||A'*r||
n_AAtr = zeros(nlambda,2);	% bounds for ||AA'*r||
eta = [];			% values of eta for which we have convergence
nllam = [];			% ... and corresponding lambda's

% entries of bidiagonal matrices
rho = zeros(itmax,1);		% diagonals of C_k and Cbar_k
sigma = zeros(itmax,1);
delta = zeros(itmax,1);		% diagonals of Rprime_k and Chat_k
gamma = zeros(itmax,1);
alpha = zeros(itmax,1);		% diagonals of Rsecond_k
beta = zeros(itmax,1);
g = zeros(itmax,1);		% RHS for Tikhonov

% data for reorthogonalizations
if reorth
	Uk = zeros(m,rst+1);
	Vk = zeros(n,rst);
end

% LSQR init
sigma(1) = norm(b);  u = b/sigma(1);
v = A'*u;  rho(1) = norm(v);  v = v/rho(1);
if reorth,  Uk(:,1) = u;  Vk(:,1) = v;  end
u = A*v-rho(1)*u;  sigma(2) = norm(u);  u = u/sigma(2);
if reorth,  u = u-Uk(:,1)*(Uk(:,1)'*u);  Uk(:,2) = u/norm(u);  end
%w = v;
%x = zeros(n,1);
phib = sigma(1);

% norms of b, A'*b and A*A'*b
norb = sigma(1);
nAtb = norb*rho(1);
nAAtb = rho(1)*sigma(1)*norm([rho(1);sigma(2)]);

% init for delta and gamma
deltab = rho(1);
den = norm([deltab;sigma(2)]);
c = deltab/den;
s = sigma(2)/den;
delta(1) = c*deltab + s*sigma(2);

% init for alpha and beta
alphab = rho(1);
cp = 1;  sp = 0;

k = 1;			% iteration index
kr = 1;			% index for restart
qk = nlambda;		% number of lambda's still outside the convergence set
done = 0;		% flag to stop iteration at convergence
if debug,  oqk = qk;  end
while (~done) && (qk) && (k < itmax)		% LSQR main iteration
	k = k+1;
	if reorth && (kr > rst)
		kr = 1;
		% add restart here
	end
	kr = kr+1;
	v = A'*u-sigma(k)*v;  rho(k) = norm(v);  v = v/rho(k);
	if reorth
		v = v-Vk(:,1:kr-1)*(Vk(:,1:kr-1)'*v);			% CGS
		%for j=1:kr-1,  v = v-Vk(:,j)*(Vk(:,j)'*v);  end	% MGS
		Vk(:,kr) = v/norm(v);
	end
	u = A*v-rho(k)*u;  sigma(k+1) = norm(u);  u = u/sigma(k+1);
	if reorth
		u = u-Uk(:,1:kr)*(Uk(:,1:kr)'*u);			% CGS
		%for j=1:kr,  u = u-Uk(:,j)*(Uk(:,j)'*u);  end		% MGS
		Uk(:,kr+1) = u/norm(u);
	end

	% compute gamma and deltab
	gamma(k) = s*rho(k);
	deltab = -c*rho(k);
	g(k-1) = c*phib;
	phib = s*phib;

	% update solution
	%x = x + phi/den * w;
	%w = v - gamma(k)/den * w;

	% compute alpha and beta
	beta(k-1) = sp*delta(k-1);
	alphap = -cp*delta(k-1);
	denp = norm([alphap;gamma(k)]);
	cp = alphap/denp;
	sp = gamma(k)/denp;
	alpha(k-1) = cp*alphap + sp*gamma(k);
	%betab = sp*deltab;			% unnecessary
	%alphab = -cp*deltab;			% unnecessary

	% compute delta and next orthogonal transformation
	den = norm([deltab;sigma(k+1)]);
	c = deltab/den;
	s = sigma(k+1)/den;
	delta(k) = c*deltab + s*sigma(k+1);

	% construct various matrices (useless now)
	%Ck = diag(rho(1:k)) + diag(sigma(2:k),-1);
	%Cbkm1 = Ck(:,1:k-1);
	%Cbk = [Ck;zeros(1,k-1) sigma(k+1)];
	%[Q R] = qr(Cbk);  Q=-Q;  R=-R;
	%Chk = R(1:k,:)';
	%Chk = diag(delta(1:k)) + diag(gamma(2:k),-1);
	%Chbkm1 = Chk(:,1:k-1);
	%[Qkp Rkp] = qr(Ck);	% le componenti (k,k) sono opposte
	%Rkp = diag([delta(1:k-1);deltab]) + diag(gamma(2:k),1);
	%[Qks Rks] = qr(Rkp');
	%Rks = diag([alpha(1:k-1);alphab]) + diag([beta(2:k-1);betab],1);
	%Rbkm1 = Rks(1:k-1,1:k-1);
	%Rbkm10 = Rbkm1(1:k-2,:);

	% compute bounds on the lambda's outside the convergence set
	for j = 1:qk
		lam = 10^llam(j);
		n_r(j,:) = d0bounds( lam, k, norb, rho, sigma);
		n_Atr(j,:) = d1bounds( lam, k, nAtb, delta, gamma);
		n_AAtr(j,:) = d2bounds( lam, k, nAAtb, alpha, beta);
	end

	% get bounds for eta and their mean
	[etalow etaupp] = etabounds( estype, ...
				n_r(1:qk,:), n_Atr(1:qk,:), n_AAtr(1:qk,:));
	etamean = (etalow + etaupp) / 2;

	if debug
		figure(51)
		loglog(10.^llam(1:qk),etaupp,'r')
		hold on
		loglog(10.^llam(1:qk),etalow,'--b')
		ax = axis;  ax(1:2) = lambdarange;  axis(ax)
		legend('upper bound','lower bound')
		title(sprintf('k=%d',k))
		hold off
	end

	% update the convergence set and check for end of iteration
	vi = abs(etaupp-etalow) < tol*etamean;
	if debug,  [10.^llam(1:qk) etamean vi],  [10.^nllam eta],  oqk=qk;  end
	if vi(qk)
		vt = find(~vi);
		if size(vt,1),  kvi = vt(end);  else,  kvi = 0;  end
		eta = [etamean(kvi+1:qk); eta];
		nllam = [llam(kvi+1:qk); nllam];
		if (qk<nlambda) && ...
				((max(eta(1:qk-kvi))>eta(qk-kvi+1)) || (qk==1))
			done = 1;
		end
		qk = kvi;
	end

	if debug && size(eta,1)
		figure(51)
		hold on
		[oqk qk]
		if oqk==qk
			loglog(10.^[llam(qk);nllam(1)],[etaupp(qk);eta(1)],...
				'r')
			loglog(10.^[llam(qk);nllam(1)],[etalow(qk);eta(1)],...
				'--b')
		end
		hh = loglog(10.^nllam,eta,'color',[0 .5 0]);
		set(hh,'linewidth',2)
		set(gca,'ylimmode','auto')
		hold off
		if isinf(debug), pause, else, pause(debug), end
	end

end

% last update for g
g(k) = c*phib;

% start refining lambda
llam = nllam;
nlambda = size(llam,1);
[mm index] = min(eta);		% current minimum
width = abs(llam(1)-llam(2));
i = 0;
while (width > tau) & (nlambda < lammax)
	i = i+1;
	if index > 1		% add a point before minimum
		ll1 = (llam(index)+llam(index-1))/2;
		lam = 10^ll1;
		resb = d0bounds( lam, k, norb, rho, sigma);
		Atrb = d1bounds( lam, k, nAtb, delta, gamma);
		AAtrb = d2bounds( lam, k, nAAtb, alpha, beta);
		[etal etau] = etabounds( estype, resb, Atrb, AAtrb);
		etam = (etal+etau)/2;
		if abs(etau-etal) >= tol*etam,  error('!!!'),  end
		llam = [llam(1:index-1);ll1;llam(index:end)];
		eta = [eta(1:index-1);etam;eta(index:end)];
		nlambda = nlambda + 1;
		index = index+1;
		width = min([width abs(llam(index)-llam(index-1))]);
	end
	if index < nlambda	% add a point after minimum
		ll2 = (llam(index)+llam(index+1))/2;
		lam = 10^ll2;
		resb = d0bounds( lam, k, norb, rho, sigma);
		Atrb = d1bounds( lam, k, nAtb, delta, gamma);
		AAtrb = d2bounds( lam, k, nAAtb, alpha, beta);
		[etal etau] = etabounds( estype, resb, Atrb, AAtrb);
		etam = (etal+etau)/2;
		if abs(etau-etal) >= tol*etam,  error('!!!'),  end
		llam = [llam(1:index);ll2;llam(index+1:end)];
		eta = [eta(1:index);etam;eta(index+1:end)];
		nlambda = nlambda + 1;
		width = min([width abs(llam(index)-llam(index+1))]);
	end
	[mm index] = min(eta);	% new minimum
	if debug
		fprintf( 'i=%g, index=%g, nlambda=%g, width=%g\n', ...
			i, index, nlambda, width);
		[10.^llam eta]
		figure(52)
		loglog(10.^llam,eta,'-o','color',[0 .5 0])
		if isinf(debug), pause, else, pause(debug), end
	end
end
if nlambda >= lammax
	warning('Max number of lambda values reached')
end

lamopt = 10.^llam(index);	% optimal lambda
if nargout > 4
	lamv = 10.^llam;
end

if k >= itmax
	warning(['Maximum number of iterations exceeded, ', ...
		'you should probably increase itmax.'])
end

if lamopt == lambdarange(1)
	warning(['Minimum is attained on the first endpoint, ', ...
		'you should probably extend lambdarange on the left.'])
elseif lamopt == lambdarange(2)
	warning(['Minimum is attained on the second endpoint, ', ...
		'you should probably extend lambdarange on the right.'])
end

% Tikhonov solution
if reorth
	Ck = diag(rho(1:k)) + diag(sigma(2:k),-1);
	ylam = bidtik2(delta,gamma,k,lamopt,0,g);
	xlam = Vk(:,1:k) * ylam;
else
	xlam = lsqr( [full(A);lamopt*eye(n)], [b;zeros(n,1)]);
end



function loupb = d0bounds( lam, k, norb, rho, sigma)
% compute bounds for d_0=norm(b)
[z1 z2] = bidtik2(rho,sigma,k,lam,1);
loupb = norb * [norm(z1) norm(z2)];



function loupb = d1bounds( lam, k, nAtb, delta, gamma)
% compute bounds for d_1=norm(A'*b)
[z1 z2] = bidtik2(delta,gamma,k,lam,2);
loupb = nAtb * [norm(z1) norm(z2)];



function loupb = d2bounds( lam, k, nAAtb, alpha, beta)
% compute bounds for d_2=norm(A*A'*b)
[z1 z2] = bidtik2(alpha,beta,k-1,lam,2);
loupb = nAAtb * [norm(z1) norm(z2)];



function [etalow,etaupp] = etabounds( nu, d0, d1, d2);
% compute bounds for error estimate eta_nu
if nu < 1
	etalow = d0(:,2).^(nu-1) .* d1(:,1).^(5-2*nu) .* d2(:,2).^(nu-3);
	etaupp = d0(:,1).^(nu-1) .* d1(:,2).^(5-2*nu) .* d2(:,1).^(nu-3);
elseif nu < 2.5
	etalow = d0(:,1).^(nu-1) .* d1(:,1).^(5-2*nu) .* d2(:,2).^(nu-3);
	etaupp = d0(:,2).^(nu-1) .* d1(:,2).^(5-2*nu) .* d2(:,1).^(nu-3);
elseif nu < 3
	etalow = d0(:,1).^(nu-1) .* d1(:,2).^(5-2*nu) .* d2(:,2).^(nu-3);
	etaupp = d0(:,2).^(nu-1) .* d1(:,1).^(5-2*nu) .* d2(:,1).^(nu-3);
else
	etalow = d0(:,1).^(nu-1) .* d1(:,2).^(5-2*nu) .* d2(:,1).^(nu-3);
	etaupp = d0(:,2).^(nu-1) .* d1(:,1).^(5-2*nu) .* d2(:,2).^(nu-3);
end



function [x1, x2, a, b, g, h] = bidtik2( a, b, k, lam, type, g)
%BIDTIK2 Tikhonov regularization for an upper bidiagonal matrix
%
%   Let B=diag(a(1:k+1))+diag(b(2:k+1),1), then
%   x=bidtik2(a,b,k,lam,0,g) solves in the least squares sense
%   the linear system
%      [B(1:k,1:k);lam*eye(k)] x = [g(1:k);zeros(k,1)]
%
%   [x1,x2]=bidtik2(a,b,k,lam,type) with type=1 compute the least squares
%   solution of the linear systems
%      [B(1:k,1:k);lam*eye(k)] x1 = [zeros(k,1);lam;zeros(k-1,1)]
%      [B(1:k,1:k+1);lam*eye(k+1)] x2 = [zeros(k,1);lam;zeros(k,1)]
%   while if type=2 it solves
%      [B(1:k,1:k);lam*eye(k)] x1 = [zeros(k,1);lam;zeros(k-1,1)]
%      [B(1:k-1,1:k);lam*eye(k)] x2 = [zeros(k-1,1);lam;zeros(k-1,1)]
%
%   The algorithm is described in L. Elden, BIT 17 (1977), 134-145.

if nargin < 5
	error('need 5 input parameters')
end

switch type
case 0
	if nargin < 6
		error('RHS is missing')
	end
	h = zeros(k,1);
case 1
	g = zeros(k,1);
	h = [lam;zeros(k,1)];
case 2
	g = zeros(k,1);
	h = [lam;zeros(k-1,1)];
otherwise
	error('unknown type')
end

lamb = lam;
for i = 1:k-1
	[G,v] = planerot([a(i);lamb]);
	a(i) = v(1);
	v = G * [b(i+1) g(i); 0 h(i)];
	b(i+1) = v(1,1);  g(i) = v(1,2);
	tt = v(2,1);          h(i) = v(2,2);
	[G,v] = planerot([lam;tt]);
	lamb = v(1);
	h([i+1 i]) = G * h([i+1 i]);
end
hk = h(k);
[G,v] = planerot([a(k);lamb]);
a(k) = v(1);
v = G * [g(k);h(k)];
g(k) = v(1);
h(k) = v(2);
if type == 1
	v = G * [b(k+1);0];
	b(k+1) = v(1);  tt = v(2);
	[G,v] = planerot([lam;tt]);
	lamb = v(1);
	h([k+1 k]) = G * h([k+1 k]);
end

switch type
case 0
	x1 = spdiags([a(1:k),b(1:k)],[0,1],k,k) \ g(1:k);
case 1
	x1 = spdiags([a(1:k),b(1:k)],[0,1],k,k) \ g(1:k);
	x2 = spdiags([[a(1:k);lamb],b(1:k+1)],[0,1],k+1,k+1) \ [g;h(k+1)];
case 2
	x1 = spdiags([a(1:k),b(1:k)],[0,1],k,k) \ g(1:k);
	x2 = spdiags([[a(1:k-1);lamb],b(1:k)],[0,1],k,k) \ [g(1:k-1);hk];
otherwise
	error('unknown type')
end

