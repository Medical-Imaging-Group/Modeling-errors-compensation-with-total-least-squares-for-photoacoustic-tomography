clear all;
close all;
clc;

rad_r = 22e-3; % sensor radius
num_sensors=60; % number of Sensors
theta = linspace(0, 2*pi, num_sensors+1);
xc = -rad_r.*cos(theta(1:end-1));
yc = rad_r.*sin(-theta(1:end-1));
% Position of the circle center
x0=0;
y0=0;
% x and y coordinates of circle
coords(1:length(xc),1) = xc + x0; 
coords(1:length(xc),2) = yc + y0; 
x_receive=coords(:,2)'; y_receive=coords(:,1)'; % receiver locations

object.Nx = 501;  % number of grid points in the x (row) direction
object.Ny = 501;  % number of grid points in the y (column) direction
object.x = 50.1e-3;              % total grid size [m]
object.y = 50.1e-3;              % total grid size [m]
dx = object.x/object.Nx;          
dy = object.y/object.Ny; 
c_x = ceil(object.Nx/2); c_y = ceil(object.Ny/2);
xx =-100;
yy =-100;
% source locations
x_img = ((1:object.Nx)-((object.Nx+1)/2))*object.x/(object.Nx-1);    x_img = repmat(x_img',1,object.Ny);
y_img = ((1:object.Ny)-((object.Ny+1)/2))*object.y/(object.Ny-1);    y_img = repmat(y_img,object.Nx,1);
M = 100;
N = 100;
indxi = ceil(object.Nx/2) - M  : ceil(object.Nx/2) + M;  
indyi = ceil(object.Ny/2) - N  : ceil(object.Ny/2) + N;  
Nxi = length(indxi);
Nyi = length(indyi);
tl=512; % Considering 512 time samples
Nx = tl*num_sensors;
A_bf = zeros(Nx,Nxi*Nyi);

tic %110 seconds
for i = 1:Nxi
    for j = 1:Nyi
        x = x_img(indyi(j),indxi(i)); y = y_img(indyi(j),indxi(i));
        [tim,mono_fold]=analytic_green([x,y],[x_receive(:),y_receive(:)],1e7,256,1500);
        sd_f=reshape(mono_fold,512,60);
        sd_f=sd_f';
        A_bf(:,(i-1)*Nyi+j) = sd_f(:);
    end
end
toc

%%%%%%%%%%%%%%% Blood vessel %%%%%%%%%%%%
bv = imread('my_drawingnew.png');
BV2=im2bw(bv,0.9);
in1=find(BV2==1);
in0=find(BV2==0);
BV2(in1)=0;
BV2(in0)=1;

%%%%%%%%%%%%%%%%%%%% Derenzo Phantom  %%%%%%%%%%%%%%%%%%
bv = imread('derenzo.png');
bv = double(rgb2gray(bv));
ind = find(bv(:)<120);
bv(ind) = 0;
ind = find(bv(:)>120);
bv(ind)=1;
BV1 = imresize(double(bv),[430 430]);
ind = find(BV1(:)<0.9);
BV1(ind) = 0;
ind = find(BV1(:)>0.9);
BV1(ind) = 1;
BV2 = BV1(10:410,20:420);

%%%%%%%%%%%%%%%%%%%% PAT phantom %%%%%%%%%%%%%%%%%%%
bv = imread('PAT_1.jpg');
bv = double(rgb2gray(bv));
bv = medfilt2(bv,[3 3]);
ind = find(bv(:)<150);
bv(ind) = 0;
ind = find(bv(:)>150);
bv(ind)=1;
BV1 = imresize(double(bv),[410 410],'bicubic');
ind = find(BV1(:)<0.7);
BV1(ind) = 0;
ind = find(BV1(:)>0.7);
BV1(ind) = 1;
BV2 = (BV1(5:405,5:405));            %% 205, 205!! 204 done for BCD
BV2 = medfilt2(BV2,[3 3]);
SE = strel('square',2)
BV2 = imdilate(BV2,SE);
BV3 = edge(BV2,'sobel');
ind = find(BV3(:)>0.5);
BV2(ind)=1;
ind = find(BV2(:)==1);
BV2(ind) = 0.5;
ind = find(BV2(:)==0);
BV2(ind) = 1;
ind = find(BV2(:)==0.5);
BV2(ind) = 0;

Mr = 200;
Nr = 200;
indxr = ceil(object_rec.Nx/2) - Mr:ceil(object_rec.Nx/2) +Mr;
indyr = ceil(object_rec.Ny/2) -Nr:ceil(object_rec.Ny/2) +Nr;
object_rec.p0 = zeros(object_rec.Nx, object_rec.Ny);
object_rec.p0(indxr,indyr) = BV2(:,:);
sensor.frequency_response = [2.25e6 70];
sdn0 = forward(object_rec, time, medium, sensor);

sdn = addNoise(sdn0, snr, 'peak'); % change snr as required

% Lanczos Tikhonov
estype = 2;		
kmax = 1000;		
reorth = 1;		
debug = 0;	
[xlam,~,kp,eta,lamv] = lanctik(A_bf,sdn,estype,[1e-8,1],kmax,reorth,[],debug);
xrecon_lanctik = reshape(xlam,201,201);

% Exponential filtering
% This method requires SVD components of the system matrix
estype = 2;	
debug = 0;		
s = diag(Sigma);
[lamoptp, x, errest, lam, X] = erresexp(A_bf, sdn, [], [1e-8,1], ...
						estype, [],  U, Sig, V, debug);
xrecon_expfil=reshape(x,201,201);

% Lanczos TTLS
lam = 1:50;
for i = 1:length(lam)   
    lambda = lam(i);
    x = lanczosttls_pat(A_bf,sdn,lambda);
    x_int(:,i) = x;
    xcurrent = x_int(:,i);
    r = sdn-A_bf*xcurrent;
    eta2(i)=norm(r,2)*norm(A_bf'*r,2)/norm(A_bf*(A_bf'*r),2);
end
[mini,ind] = min(eta2); 
lamopt = lam(ind);
xprop = x_int(:,ind);
xrecon_lttls = reshape(xprop,201,201);




