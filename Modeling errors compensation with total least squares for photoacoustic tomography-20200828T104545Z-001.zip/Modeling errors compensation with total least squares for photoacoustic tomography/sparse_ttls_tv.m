function x_tv = sparse_ttls_tv(A_b,sdn2,BVn)

% A_b = system matrix
% sdn2 = measurement data b
% BVn = Target image

nx = size(A_b,1);
ny = size(A_b,2);
Err1 = zeros(nx,ny);

tic
for iter = 1:100
    [x_tv,lamopt] = sparse_tv(A_b,sdn2,Err1); % 160 seconds
    s1 = length(x_tv);
    iden = eye(s1);
    
    sem = shermor_my(eye(40401),x_tv(:),x_tv(:)); % using shermon-morisson identity
    int1 = x_tv'*sem;
    num = (sdn2 - A_b*x_tv);
    Err2 = num*int1;
    
    norme(iter) = norm(Err2(:) - Err1(:));
    if norme(iter) < 1e-3
       break;
    end

    Err1 = Err2;
end
toc

x_tvf = reshape(x_tv,201,201);
figure,imshow(x_tvf,[]); colorbar;

PCbw = pearson_correlation(BVn,x_tvf)
CNRbw = CONTRAST_NOISE_RATIO(BVn,x_tvf)









