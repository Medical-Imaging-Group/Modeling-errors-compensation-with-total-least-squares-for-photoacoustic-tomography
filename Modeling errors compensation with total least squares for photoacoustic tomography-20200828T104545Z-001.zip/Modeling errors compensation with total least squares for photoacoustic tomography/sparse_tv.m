function [x_tv,lamopt] = sparse_tv(A_b,sdn2,Err1)

lambdarange = [1e-8;1]; 
nlambda = 25;		% number of lambda values for initial grid
tol = 1e-2;		% tolerance for upper and lower bounds of eta
lammax = 64;		% max number of lambda values
tau = 1e-2;		% default accuracy for lambda

% lambda grid
lambdarange = sort(lambdarange(:));
llamfirst = log10(lambdarange(1));
llamlast = log10(lambdarange(2));
lstep = (llamlast-llamfirst)/(nlambda-1);
llam = llamfirst + lstep*[0:nlambda-1]';
qk = nlambda;
for j = 1:qk
		lam(j) = 10^llam(j);
end

H = A_b+Err1;
Ht = H';
y = sdn2;
p = 1;
normfac = 1;
err = 1e-6;
insweep = 10;
tol = 1e-4;
x_initial = Ht*(y);
alpha = 1.0*normfac;
x = x_initial;
%lambdaInit = decfac*max(abs(Ht*(y))); lambda = lambdaInit;

TV= compute_total_variation(x); 
x_opt = zeros(40401,length(lam));
f_current = norm(y-H*(x_initial)) + lam(1)*TV;

 for i = 1:length(lam)   
      lambda = lam(i);
      w = ones(length(x),1);
      
       for ins = 1:insweep
           f_previous = f_current;
           x = SoftTh(x + (Ht*(y - H*(x)))/alpha, w.*lambda/(2*alpha));
           w = abs(x).^(p-1);
           f_current = norm(y-H*(x)) + lambda*TV;
        
           if norm(f_current-f_previous)/norm(f_current + f_previous)<tol
              break;
           end
      end
     
      x_opt(:,i) = x;
TV= compute_total_variation(x);  % TV norm of image x

xlambda = x_opt(:,i);
residue = sdn2-A_b*xlambda;
r=residue;
eta2(i)=norm(r,2)*norm(A_b'*r,2)/norm(A_b*(A_b'*r),2);
end

[mini,index] = min(eta2); 
lamopt=lam(index);
x_tv = x_opt(:,index);

