function [x_lambda,rho,eta] = exp_svd(U,s,V,b,lambda,x_0)

% Initialization.
if (min(lambda)<0)
  error('Illegal regularization parameter lambda')
end
m = size(U,1);
n = size(V,1);
[p,ps] = size(s);
beta = U(:,1:p)'*b;

nlambda=5;
phi=zeros(length(b),nlambda);

ll = length(lambda); x_lambda = zeros(n,ll);
rho = zeros(ll,1); eta = zeros(ll,1);

% Treat each lambda separately.
if (ps==1)

  % The standard-form case.
  if (nargin==6), omega = V'*x_0; end
  for i=1:ll
        c = -(s.^2)./(lambda(i)^2);
        phi(:,i) = ones(size(c)) - exp(c);
        zeta(:,i) = phi(:,i).*beta;
      
    if (nargin==5)
      x_lambda(:,i) = V(:,1:p)*(zeta(:,i)./(s));
      rho(i) = lambda(i)^2*norm(beta./(s));
    else
      x_lambda(:,i) = V(:,1:p)*...
        ((zeta(:,i) + lambda(i)^2*omega)./(s));
      rho(i) = lambda(i)^2*norm((beta - s.*omega)./(s));
    end
    eta(i) = norm(x_lambda(:,i));
  end
  if (nargout > 1 & size(U,1) > p)
    rho = sqrt(rho.^2 + norm(b - U(:,1:n)*[beta;U(:,p+1:n)'*b])^2);
  end
end
