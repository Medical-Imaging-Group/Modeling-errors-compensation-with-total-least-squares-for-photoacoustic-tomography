function [x_k] = lanczosttls_pat(A_b,sdn2,lstep)

[Uk,B_k,Vk] = lanc_b(A_b,sdn2,lstep,1);

beta = norm(sdn2(:));
bete = beta.*eye(lstep+1,1);

[Usvd,ssvd,Vsvd] = csvd([B_k,bete],'full'); 

[xk] = ttls_pat(Vsvd,lstep);
x_k = Vk*xk;
